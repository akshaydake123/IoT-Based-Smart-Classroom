package com.example.akshay.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoCredential;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by Akshay on 12-03-2018.
 */

public class InsertTimeTable extends AppCompatActivity {

    private final AppCompatActivity activity = InsertTimeTable.this;

    private NestedScrollView nestedScrollView;

    private TextInputLayout textInputLayoutDate;
    private TextInputLayout textInputLayoutDay;
    private TextInputLayout textInputLayoutTime;
    private TextInputLayout textInputLayoutSubject;
    private TextInputLayout textInputLayoutFacultyName;

    private TextInputEditText textInputEditTextDate;
    private TextInputEditText textInputEditTextDay;
    private TextInputEditText textInputEditTextTime;
    private TextInputEditText textInputEditTextSubject;
    private TextInputEditText textInputEditTextFacultyName;

    private AppCompatButton add;

   private String classroomno=null;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_timetable);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        classroomno = getIntent().getStringExtra("classroomno");
        System.out.println("Insert time table = "+ classroomno);
        initViews();

        add = (AppCompatButton) findViewById(R.id.AddTimeTable);
        //final Button button = findViewById(R.id.buttondemo);
        final RequestQueue queue = Volley.newRequestQueue(this);
        //final String url = "http://172.16.82.121:3000/api/v1/postdata"; // your URL
          final String url = "https://smartclassroom.herokuapp.com/api/v1/postdata/";
        queue.start();
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                 BasicDBObject document = new BasicDBObject();
                    BasicDBObject subdocument = new BasicDBObject();
                    document.put("classroomno", classroomno);
                    document.put("date", textInputEditTextDate.getText().toString());
                    document.put("day", textInputEditTextDay.getText().toString());
                    document.put("slot", textInputEditTextTime.getText().toString());
                    document.put("faculty", textInputEditTextFacultyName.getText().toString());
                    document.put("subject", textInputEditTextSubject.getText().toString());




                JsonObjectRequest jsObjRequest = null;
                jsObjRequest = new
                        JsonObjectRequest(Request.Method.POST,
                        url, new JSONObject(document),
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {
                                try {

                                    Toast.makeText(getApplicationContext(),response.getString("message"),Toast.LENGTH_SHORT).show();

                                   String  s = response.getString("message");
                                    textInputEditTextDate.setText(response.getString("message"));

                                  if(s.equalsIgnoreCase("Inserted Successfully"))
                                  {
                                      Intent i = new Intent(InsertTimeTable.this,ClassTimeTableActivity.class);
                                    startActivity(i);
                                  }

                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        //textInputEditTextDate.setText(error.toString());
                        System.out.println(error.toString());
                        if(!error.toString().equalsIgnoreCase("null"))
                        {
                            Intent i = new Intent(InsertTimeTable.this,ClassroomActivity.class);
                            startActivity(i);
                        }
                        Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
                    }
                });
                queue.add(jsObjRequest);


            }
        });

    }








    private void initViews() {
        nestedScrollView = (NestedScrollView) findViewById(R.id.nestedScrollView);

        textInputLayoutDate = (TextInputLayout) findViewById(R.id.textInputLayoutDate);
        textInputLayoutDay = (TextInputLayout) findViewById(R.id.textInputLayoutDay);
        textInputLayoutTime = (TextInputLayout) findViewById(R.id.textInputLayoutTime);
        textInputLayoutSubject = (TextInputLayout) findViewById(R.id.textInputLayoutSubject);
        textInputLayoutFacultyName = (TextInputLayout) findViewById(R.id.textInputLayoutFacultyName);

        textInputEditTextDate = (TextInputEditText) findViewById(R.id.textInputEditTextDate);
        textInputEditTextDay = (TextInputEditText) findViewById(R.id.textInputEditTextDay);
        textInputEditTextTime = (TextInputEditText) findViewById(R.id.textInputEditTextTime);
        textInputEditTextSubject = (TextInputEditText) findViewById(R.id.textInputEditTextSubject);
        textInputEditTextFacultyName = (TextInputEditText) findViewById(R.id.textInputEditTextFacultyName);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public void onBackPressed()
    {

        //thats it
    }
}