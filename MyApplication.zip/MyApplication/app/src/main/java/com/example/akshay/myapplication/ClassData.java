package com.example.akshay.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by Akshay on 13-03-2018.
 */


public class ClassData extends AppCompatActivity {


    CardView mycard,mycard1,mycard2,mycard4,mycard5,mycard6,mycard7,mycard3 ;
    Intent i,i1,i2,i3,i4,i5,i6 ,i7;
    LinearLayout ll;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.class_data);

        ll = (LinearLayout) findViewById(R.id.la1);
        mycard = (CardView) findViewById(R.id.r305);
        mycard1 = (CardView) findViewById(R.id.r306);
        mycard2 = (CardView) findViewById(R.id.r307);
        mycard3 = (CardView) findViewById(R.id.r308);

        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);


        i = new Intent(ClassData.this,ClassStatusActivity.class);
        mycard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i.putExtra("classroomno", "305");
                 startActivity(i);
            }
        });
        i1 = new Intent(ClassData.this,ClassStatusActivity.class);
        mycard1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                i1.putExtra("classroomno", "306");
                startActivity(i1);
            }
        });
        i2 = new Intent(ClassData.this,ClassStatusActivity.class);
        mycard2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i2.putExtra("classroomno", "307");
                startActivity(i2);
            }
        });
        i3 = new Intent(ClassData.this,ClassStatusActivity.class);
        mycard3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i3.putExtra("classroomno", "308");
                startActivity(i3);
            }
        });

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                Intent  i = new Intent(ClassData.this,MainActivity.class);
                startActivity(i);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public void onBackPressed()
    {

        //thats it
    }
}
