package com.example.akshay.myapplication;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

/**
 * Created by Akshay on 07-03-2018.
 */

public class FeedBackActivity extends AppCompatActivity {


     EditText name,email,classroom,mesg;
     Button feedback;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
   /*     name = (EditText) findViewById(R.id.feedbackname);
        email = (EditText) findViewById(R.id.feedbackemail);
        classroom = (EditText) findViewById(R.id.feedbackclassroomname);
        // = (EditText) findViewById(R.id.feedbackname);
*/
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}

