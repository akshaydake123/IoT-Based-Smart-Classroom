package com.example.akshay.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

/**
 * Created by Akshay on 07-03-2018.
 */

public class ClassroomActivity extends AppCompatActivity{


    CardView mycard,mycard1,mycard2,mycard4,mycard5,mycard6,mycard7,mycard3 ;
    Intent i,i1,i2,i3,i4,i5,i6 ,i7;
    LinearLayout ll;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classroom);

        ll = (LinearLayout) findViewById(R.id.laa);
        mycard4 = (CardView) findViewById(R.id.r305);
        mycard5 = (CardView) findViewById(R.id.r306);
        mycard6 = (CardView) findViewById(R.id.r307);
        mycard7 = (CardView) findViewById(R.id.r308);

        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);


        i = new Intent(ClassroomActivity.this,ClassTimeTableActivity.class);
        mycard4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i.putExtra("classroomno", "305");
                startActivity(i);
            }
        });
        i1 = new Intent(ClassroomActivity.this,ClassTimeTableActivity.class);
        mycard5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i1.putExtra("classroomno", "306");
                startActivity(i1);
            }
        });
        i2 = new Intent(ClassroomActivity.this,ClassTimeTableActivity.class);
        mycard6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i2.putExtra("classroomno", "307");
                startActivity(i2);
            }
        });
        i3 = new Intent(ClassroomActivity.this,ClassTimeTableActivity.class);
        mycard7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                i3.putExtra("classroomno", "308");
                startActivity(i3);
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent i = new Intent(ClassroomActivity.this,MainActivity.class);

                startActivity(i);
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public void onBackPressed()
    {

        //thats it
    }
}
