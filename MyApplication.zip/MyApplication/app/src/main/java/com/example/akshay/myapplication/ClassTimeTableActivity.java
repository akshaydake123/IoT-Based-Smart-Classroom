package com.example.akshay.myapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.util.JSON;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;


/**
 * Created by Akshay on 07-03-2018.
 */

public class ClassTimeTableActivity extends AppCompatActivity {


    private String TAG = ClassTimeTableActivity.class.getSimpleName();

    private ProgressDialog pDialog;
    private ListView lv;
    private String classroomno=null;
    // URL to get contacts JSON
//    private static String url = "http://172.16.82.121:3000/api/v1/display";

    ArrayList<HashMap<String, String>> contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        android.support.v7.app.ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);
        contactList = new ArrayList<>();
         classroomno = getIntent().getStringExtra("classroomno");
        lv = (ListView) findViewById(R.id.list);


        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Click action
                Intent intent = new Intent(ClassTimeTableActivity.this, InsertTimeTable.class);
                intent.putExtra("classroomno", classroomno);
                startActivity(intent);
            }
        });
        new GetContacts().execute();
    }

    /**
     * Async task class to get json by making HTTP call
     */
    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(ClassTimeTableActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            HttpHandler sh = new HttpHandler();
            String classroomno = getIntent().getStringExtra("classroomno");
            String url = "https://smartclassroom.herokuapp.com/api/v1/display/"+classroomno;
            // Making a request to url and getting response
            System.out.println(url);
            String jsonStr = sh.makeServiceCall(url);

            Log.e(TAG, "Response from url: " + jsonStr);
               System.out.println(jsonStr);
            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = null;
                    try {
                        jsonObj = new JSONObject(jsonStr);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    // Getting JSON Array node
                    //JSONArray itemArray = new JSONArray(itemsJson);
                    JSONArray contacts = new JSONArray(jsonStr);

                    // looping through All Contacts
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        //String id = c.getString("id");
                        String classroom = c.getString("classroomno");
                        String date = c.getString("date");
                        String day = c.getString("day");
                        String mobile = c.getString("slot");
                        String home = c.getString("subject");
                        String office = c.getString("faculty");

                        // tmp hash map for single contact
                        HashMap<String, String> contact = new HashMap<>();

                        // adding each child node to HashMap key => value
                        contact.put("classroomno", "Classroom Number : " + classroom);
                        contact.put("date","Date : " + date);
                        contact.put("day","Day : " + day);
                        contact.put("mobile","Slot : " + mobile);
                        contact.put("home","Subject : "+ home);
                        contact.put("office","Faculty : " + office);

                        // adding contact to contact list
                        contactList.add(contact);


                    }

                } catch (final JSONException e) {
                    Log.e(TAG, "Json parsing error: " + e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(getApplicationContext(),
                                    "Json parsing error: " + e.getMessage(),
                                    Toast.LENGTH_LONG)
                                    .show();
                        }
                    });

                }
            } else {
                Log.e(TAG, "Couldn't get json from server.");
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(getApplicationContext(),
                                "Couldn't get json from server. Check LogCat for possible errors!",
                                Toast.LENGTH_LONG)
                                .show();
                    }
                });

            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            if (pDialog.isShowing() && pDialog!=null)
                pDialog.dismiss();
            /**
             * Updating parsed JSON data into ListView
             * */

            ListAdapter adapter = new SimpleAdapter(
                    ClassTimeTableActivity.this, contactList,
                    R.layout.list_item, new String[]{"classroomno","date", "day",
                    "mobile","home","office"}, new int[]{R.id.classroomno,R.id.date,
                    R.id.day, R.id.mobile,R.id.home1,R.id.office});

            lv.setAdapter(adapter);
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                //Write your logic here

              Intent  i = new Intent(ClassTimeTableActivity.this,ClassroomActivity.class);

              startActivity(i);
                this.finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public void onBackPressed()
    {

        //thats it
    }
}